import React, {useState} from 'react'
import { Dropdown, Container } from 'react-bootstrap'
import Carousel from 'react-bootstrap/Carousel'
import {Modal, Button} from 'react-bootstrap'
import './movie.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import Card from 'react-bootstrap/Card'
import { FcStart, FcCollaboration, FcBusinesswoman, FcBusinessman } from "react-icons/fc";

export default function MovieReview() {

        const [show, setShow] = useState(false);
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);

    return (
            <>   

<link href='https://fonts.googleapis.com/css?family=ABeeZee' rel='stylesheet'></link>
<link rel="stylesheet" type="text/css" href="path/to/bootstrap.css"></link>

<script src="https://unpkg.com/react/umd/react.production.min.js" crossorigin></script>

<script
  src="https://unpkg.com/react-dom/umd/react-dom.production.min.js"
  crossorigin></script>

<script
  src="https://unpkg.com/react-bootstrap@next/dist/react-bootstrap.min.js"
  crossorigin></script>
<div className="header">  
<Container>
<div className="botao-login"> 
<Button className="nextButton" onClick={handleShow}>
            Sign in        
          </Button>
    
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Welcome back!</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <div className="email">    
            <h5 className="modal-input">E-mail</h5>
            <input type="email"></input>
            </div><div className="password">    
            <h5 className="modal-input">Password</h5>
            <input type="password"></input>
            </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                OK
              </Button>
              <Button variant="primary" onClick={handleClose}>
                Forgot password
              </Button>
              <Button variant="primary" onClick={handleClose}>
                Sign up
              </Button>
            </Modal.Footer>
          </Modal>
          </div>

<div className="upper-header col-md-12 col-lg-12 col-sm-12 col-xs-12">   

<div className="title-page col-md-6 col-lg-6 col-sm-12 col-xs-12"> 
<h1><FcStart />Movie Review</h1>
<h2>Rate your favourite movies, share your reviews, and make your own lists!</h2>
</div>

<div class="searchbar">
        <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
            <div class="input-group">
                <input class="form-control border-secondary py-2" type="search" placeholder="What would you like to rate today?"></input>
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary py-2" type="button">
                        <span>GO!</span>
                    </button>
                </div>
        </div>
    </div>
</div>
</div> 
<div className="menu col-md-12 col-lg-12 col-sm-12 col-xs-12">
<Dropdown>
    <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">
      Comedies
    </Dropdown.Toggle>

    <Dropdown.Menu variant="dark">
      <Dropdown.Item href="#/action-1" active>
        Best rated
      </Dropdown.Item>
      <Dropdown.Item href="#/action-2">Most popular</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Trending</Dropdown.Item>
      <Dropdown.Divider />
      <Dropdown.Item href="#/action-4">Latest releases</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>

  <Dropdown>
    <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">
      Dramas
    </Dropdown.Toggle>

    <Dropdown.Menu variant="dark">
      <Dropdown.Item href="#/action-1" active>
        Best rated
      </Dropdown.Item>
      <Dropdown.Item href="#/action-2">Most popular</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Trending</Dropdown.Item>
      <Dropdown.Divider />
      <Dropdown.Item href="#/action-4">Latest releases</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>

  <Dropdown>
    <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">
      Action
    </Dropdown.Toggle>

    <Dropdown.Menu variant="dark">
      <Dropdown.Item href="#/action-1" active>
        Best rated
      </Dropdown.Item>
      <Dropdown.Item href="#/action-2">Most popular</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Trending</Dropdown.Item>
      <Dropdown.Divider />
      <Dropdown.Item href="#/action-4">Latest releases</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>

  <Dropdown>
    <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">
      Sci-Fi
    </Dropdown.Toggle>

    <Dropdown.Menu variant="dark">
      <Dropdown.Item href="#/action-1" active>
        Best rated
      </Dropdown.Item>
      <Dropdown.Item href="#/action-2">Most popular</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Trending</Dropdown.Item>
      <Dropdown.Divider />
      <Dropdown.Item href="#/action-4">Latest releases</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>

  <Dropdown>
    <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">
      Short films
    </Dropdown.Toggle>

    <Dropdown.Menu variant="dark">
      <Dropdown.Item href="#/action-1" active>
        Best rated
      </Dropdown.Item>
      <Dropdown.Item href="#/action-2">Most popular</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Trending</Dropdown.Item>
      <Dropdown.Divider />
      <Dropdown.Item href="#/action-4">Latest releases</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>
  
  <Dropdown>
    <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">
      Foreign
    </Dropdown.Toggle>

    <Dropdown.Menu variant="dark">
      <Dropdown.Item href="#/action-1" active>
        Best rated
      </Dropdown.Item>
      <Dropdown.Item href="#/action-2">Most popular</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Trending</Dropdown.Item>
      <Dropdown.Divider />
      <Dropdown.Item href="#/action-4">Latest releases</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>
  </div>
  </Container>  
  </div>

  <Container>
  <div className="latest-reviewed">
<h3>Latest reviewed</h3>

<Carousel fade className="carousel-desktop col-lg-12 col-md-12">
   
  <Carousel.Item>
    
    <div className="carousel-comp col-md-2 col-lg-2">  
    <img responsive
      className="d-block"
      src="https://i.pinimg.com/originals/d9/a7/6c/d9a76cb94a33e46514134152ef8f2643.jpg"
      alt="Rtd-movie-1"
    />
    <a href="/"><FcCollaboration />19.5K rated it</a></div>
    <div className="carousel-comp col-md-2 col-lg-2">  
    <img responsive
      className="d-block"
      src="https://i.pinimg.com/originals/33/72/6e/33726e086fd631da13160fa503381b81.jpg"
      alt="Rtd-movie-2"
    />
    <a href="/"><FcCollaboration />11.3K rated it</a></div>
    <div className="carousel-comp col-md-2 col-lg-2">  
    <img responsive
      className="d-block"
      src="https://i.pinimg.com/originals/53/61/39/53613989662f0a10490aed220144eb7e.jpg"
      alt="Rtd-movie-3"
    />
    <a href="/"><FcCollaboration />1.4K rated it</a></div>
    <div className="carousel-comp col-md-2 col-lg-2">  
    <img responsive
      className="d-block"
      src="https://m.media-amazon.com/images/M/MV5BMzI4OTQ0MDQyNl5BMl5BanBnXkFtZTcwODY5MjQwNA@@._V1_.jpg"
      alt="Rtd-movie-4"
    /><a href="/"><FcCollaboration />8.9K rated it</a></div>

    
  </Carousel.Item>

  <Carousel.Item>
  <div className="carousel-comp col-md-2 col-lg-2"> 
    <img responsive
      className="d-block"
      src="https://cdn.shopify.com/s/files/1/0057/3728/3618/products/ef4b93ef8f7157de3f97ae1ff5d21b56_0526bb98-1f4a-4da5-b928-b0025f5e6371_500x.jpg?v=1573585487"
      alt="Rtd-movie-5"
    /><a href="/"><FcCollaboration />7K rated it</a></div>
    <div className="carousel-comp col-md-2 col-lg-2"> 
    <img responsive
      className="d-block"
      src="https://image.invaluable.com/housePhotos/luxewest/17/631317/H21193-L151922566.jpg"
      alt="Rtd-movie-6"
    /><a href="/"><FcCollaboration />1.9K rated it</a></div>
    <div className="carousel-comp col-md-2 col-lg-2"> 
    <img responsive
      className="d-block"
      src="https://m.media-amazon.com/images/M/MV5BMjUxMDQwNjcyNl5BMl5BanBnXkFtZTgwNzcwMzc0MTI@._V1_.jpg"
      alt="Rtd-movie-7"
    /><a href="/"><FcCollaboration />2.4K rated it</a></div>
    <div className="carousel-comp col-md-2 col-lg-2"> 
    <img responsive
      className="d-block"
      src="https://m.media-amazon.com/images/I/511dltIuAEL._AC_.jpg"
      alt="Rtd-movie-8"
    /><a href="/"><FcCollaboration />8.8K rated it</a></div>

    
  </Carousel.Item>


</Carousel>

<Carousel fade className="carousel-mobile">
   
  <Carousel.Item className="col-sm-12 col-xs-12">
    
    <div className="carousel-comp col-sm-4 col-xs-4">  
    <img responsive
      className="d-block"
      src="https://i.pinimg.com/originals/d9/a7/6c/d9a76cb94a33e46514134152ef8f2643.jpg"
      alt="Rtd-movie-1"
    />
    <a href="/"><FcCollaboration />19.5K rated it</a></div>
    <div className="carousel-comp col-sm-4 col-xs-4">  
    <img responsive
      className="d-block"
      src="https://i.pinimg.com/originals/33/72/6e/33726e086fd631da13160fa503381b81.jpg"
      alt="Rtd-movie-2"
    />
    <a href="/"><FcCollaboration />11.3K rated it</a></div>
    </Carousel.Item><Carousel.Item className="col-sm-12 col-xs-12">
    <div className="carousel-comp col-sm-4 col-xs-4">  
    <img responsive
      className="d-block"
      src="https://i.pinimg.com/originals/53/61/39/53613989662f0a10490aed220144eb7e.jpg"
      alt="Rtd-movie-3"
    />
    <a href="/"><FcCollaboration />1.4K rated it</a></div>
    <div className="carousel-comp col-sm-4 col-xs-4">  
    <img responsive
      className="d-block"
      src="https://m.media-amazon.com/images/M/MV5BMzI4OTQ0MDQyNl5BMl5BanBnXkFtZTcwODY5MjQwNA@@._V1_.jpg"
      alt="Rtd-movie-4"
    /><a href="/"><FcCollaboration />8.9K rated it</a></div>

    
  </Carousel.Item>

  <Carousel.Item className="col-sm-12 col-xs-12">
  <div className="carousel-comp col-sm-4 col-xs-4"> 
    <img responsive
      className="d-block"
      src="https://cdn.shopify.com/s/files/1/0057/3728/3618/products/ef4b93ef8f7157de3f97ae1ff5d21b56_0526bb98-1f4a-4da5-b928-b0025f5e6371_500x.jpg?v=1573585487"
      alt="Rtd-movie-5"
    /><a href="/"><FcCollaboration />7K rated it</a></div>
    <div className="carousel-comp col-sm-4 col-xs-4"> 
    <img responsive
      className="d-block"
      src="https://image.invaluable.com/housePhotos/luxewest/17/631317/H21193-L151922566.jpg"
      alt="Rtd-movie-6"
    /><a href="/"><FcCollaboration />1.9K rated it</a></div>
    </Carousel.Item><Carousel.Item className="col-sm-12 col-xs-12">
    <div className="carousel-comp col-sm-4 col-xs-4"> 
    <img responsive
      className="d-block"
      src="https://m.media-amazon.com/images/M/MV5BMjUxMDQwNjcyNl5BMl5BanBnXkFtZTgwNzcwMzc0MTI@._V1_.jpg"
      alt="Rtd-movie-7"
    /><a href="/"><FcCollaboration />2.4K rated it</a></div>
    <div className="carousel-comp col-sm-4 col-xs-4"> 
    <img responsive
      className="d-block"
      src="https://m.media-amazon.com/images/I/511dltIuAEL._AC_.jpg"
      alt="Rtd-movie-8"
    /><a href="/"><FcCollaboration />8.8K rated it</a></div>

    
  </Carousel.Item>


</Carousel>

</div>
<div className="lists-body">
<h4>Most popular</h4>   
<div className="column-lists col-md-12 col-lg-12 col-sm-12 col-xs-12">
 
<div className="lists col-md-4 col-lg-3 col-sm-12 col-xs-12">
<h3>Lists</h3>
<ul className="pop-lists">
<li><a href="/">90s movies</a></li>
<li><a href="/">Classic movies</a></li>
<li><a href="/">Oscar winners</a></li>
<li><a href="/">Super-hero movies</a></li>
<li><a href="/">Slasher movies</a></li>
</ul>
</div>

<div className="lists col-md-4 col-lg-3 col-sm-12 col-xs-12">
<h3>Users</h3>
<ul className="pop-lists">
<li><a href="/"><FcBusinesswoman />Alice</a></li>
<li><a href="/"><FcBusinessman />Joseph</a></li>
<li><a href="/"><FcBusinesswoman />Susan</a></li>
<li><a href="/"><FcBusinessman />José</a></li>
<li><a href="/"><FcBusinessman />Tyler</a></li>
</ul>
</div>

<div className="lists col-md-4 col-lg-3 col-sm-12 col-xs-12">
<h3>Releases</h3>
<ul className="pop-lists">
<li><a href="/">Cruella</a></li>
<li><a href="/">Jungle Cruise</a></li>
<li><a href="/">The Vault</a></li>
<li><a href="/">Black Widow</a></li>
<li><a href="/">The Woman in the Window</a></li>
</ul>
</div>
</div>
</div>

<Container>
<div className="content col-md-12 col-lg-12 col-sm-12 col-xs-12">

<Card style={{ width: '18rem' }} className="col-md-4 col-lg-3 col-sm-12 col-xs-12">
  <Card.Img variant="top" responsive src="https://resize-media.festival-cannes.com/fit-in/2560x1620/media_image/0001/74/b710f90eea0fd1991c06fca4dcf4d36854dc7113.jpeg" />
  <Card.Body>
    <Card.Title>Wanna get a trip to Cannes?</Card.Title>
    <Card.Text>
      Send your shortfilm to our contest!
    </Card.Text>
    <Button variant="primary">Join!</Button>
  </Card.Body>
</Card>

<Card style={{ width: '18rem' }} className="col-md-4 col-lg-3 col-sm-12 col-xs-12">
  <Card.Img variant="top" responsive src="https://m.media-amazon.com/images/G/01/gear/portal/5400Products-Stacked._CB468606953_.jpg" />
  <Card.Body>
    <Card.Title>Merch</Card.Title>
    <Card.Text>
      Show us some love buying our merch, check out our best offers now!
    </Card.Text>
    <Button variant="primary">Buy!</Button>
  </Card.Body>
</Card>

<Card style={{ width: '18rem' }} className="col-md-4 col-lg-3 col-sm-12 col-xs-12">
  <Card.Img variant="top" responsive src="https://www.cinematographe.it/wp-content/uploads/2015/03/Martin-Scorsese-01.jpg" />
  <Card.Body>
    <Card.Title>Martin Scorsese</Card.Title>
    <Card.Text>
      Watch our series celebrating the geniousity of one of Hollywood's greatest masters!
    </Card.Text>
    <Button variant="primary">Watch!</Button>
  </Card.Body>
</Card>

</div>
</Container>
  </Container>
  
<div className="footer col-md-12 col-lg-12 col-sm-12 col-xs-12">

<Container>
<div className="footer-content">
<div className="footer-icon"><FcStart /></div>
<div>
<ul>
<li><a href="/">About us</a></li>
<li><a href="/">Privacy politics</a></li>
<li><a href="/">Terms and Conditions</a></li>
<li><a href="/">Assistance</a></li>
<li><a href="/">Contact</a></li>
</ul>
</div>
<div>
<ul>
<li><a href="/">MR in the media</a></li>
<li><a href="/">Special content</a></li>
<li><a href="/">Our apps</a></li>
<li><a href="/">News</a></li>
<li><a href="/">Contests</a></li>
</ul>
</div>
<div>
<ul>
<li><a href="/">Instagram</a></li>
<li><a href="/">Facebook</a></li>
<li><a href="/">Twitter</a></li>
<li><a href="/">TikTok</a></li>
<li><a href="/">YouTube</a></li>
</ul>
</div>
</div>

<div className="footer-text">
<span>Movie Review, 2021. Developed by Bianca Leal.</span>
</div>
</Container>

</div>
</>
);
}