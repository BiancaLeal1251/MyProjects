import React from 'react'
import Carousel from 'react-bootstrap/Carousel'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import NavDropdown from 'react-bootstrap/NavDropdown'
import Navbar from 'react-bootstrap/Navbar'
import { StarFill, HeartFill, ClockHistory, Search, EyeFill, Info, Phone, ViewList, PersonPlusFill, BriefcaseFill, Bag, Exclamation, Question, Tools, DropletHalf } from 'react-bootstrap-icons';
import { FaFacebook, FaYoutube, FaInstagram } from "react-icons/fa"
import './blog.css';
export default function HomePage() {
return (      
<div id="blog-skincare" className="col-md-12 col-lg-12 col-xs-12 col-sm-12">
   <link href='https://fonts.googleapis.com/css?family=Assistant' rel='stylesheet'>
   </link>
   <div className="header-blog col-md-12 col-lg-12">
      <div className="header container">
         <div className="title-search col-md-9 col-lg-9 col-sm-9 col-xs-12">
            <div className="header-text">
               <div>
                  <h1 className="blog-name">Skincare Tips and Tricks</h1>
                  <h2 className="blog-title">Everything about facial self-care in one platform!</h2>
               </div>
            </div>
            <div className="searchbar col-md-3 col-lg-3 col-sm-3 col-xs-12">
               <input type="text" placeholder="Search anything here!"></input>  
               <button type="submit">
                  <Search className="search" />
               </button>
            </div>
         </div>
         <Navbar collapseOnSelect expand="lg">
            <Container>
               <Navbar.Brand href="#home">
                  <DropletHalf/>
                  Browse by your skin type
               </Navbar.Brand>
               <Navbar.Toggle aria-controls="responsive-navbar-nav" />
               <Navbar.Collapse id="responsive-navbar-nav">
                  <Nav className="me-auto">
                     <NavDropdown title="Oily skin" id="collasible-nav-dropdown">
                        <NavDropdown.Item href="#Main necessities/3.1">Main necessities</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.2">Anti-aging</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.3">Moisturizing and protection</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item href="#Main necessities/3.4">Best products</NavDropdown.Item>
                     </NavDropdown>
                     <NavDropdown title="Dry skin" id="collasible-nav-dropdown">
                        <NavDropdown.Item href="#Main necessities/3.1">Main necessities</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.2">Anti-aging</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.3">Moisturizing and protection</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item href="#Main necessities/3.4">Best products</NavDropdown.Item>
                     </NavDropdown>
                     <NavDropdown title="Normal skin" id="collasible-nav-dropdown">
                        <NavDropdown.Item href="#Main necessities/3.1">Main necessities</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.2">Anti-aging</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.3">Moisturizing and protection</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item href="#Main necessities/3.4">Best products</NavDropdown.Item>
                     </NavDropdown>
                     <NavDropdown title="Combination skin" id="collasible-nav-dropdown">
                        <NavDropdown.Item href="#Main necessities/3.1">Main necessities</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.2">Anti-aging</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.3">Moisturizing and protection</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item href="#Main necessities/3.4">Best products</NavDropdown.Item>
                     </NavDropdown>
                     <NavDropdown title="Sensitive skin" id="collasible-nav-dropdown">
                        <NavDropdown.Item href="#Main necessities/3.1">Main necessities</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.2">Anti-aging</NavDropdown.Item>
                        <NavDropdown.Item href="#Main necessities/3.3">Moisturizing and protection</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item href="#Main necessities/3.4">Best products</NavDropdown.Item>
                     </NavDropdown>
                  </Nav>
               </Navbar.Collapse>
            </Container>
         </Navbar>
      </div>
   </div>
   <div className="carousel-content">
      <Carousel variant="dark" className="container col-md-12 col-lg-12 col-sm-12 col-xs-12">
         <Carousel.Item>
            <img
               className="responsive"
               src="https://media.istockphoto.com/photos/aloe-vera-plant-picture-id510241670?k=20&m=510241670&s=612x612&w=0&h=sUlx5TCje7pLGK2bgDSkg87lT5xBP4-GBqd0o3YQDK8="
               alt="First slide"
               />
            <Carousel.Caption>
               <h5><strong>Aloe vera is not just for your hair...</strong></h5>
               <a href="/">Get to know the soothing properties of aloe vera for sensitive skin!</a>
               <small>Image source: https://bit.ly/3yQdYJk</small>
            </Carousel.Caption>
         </Carousel.Item>
         <Carousel.Item>
            <img
               className="responsive"
               src="https://bit.ly/3zRWNYX"
               alt="Second slide"
               />
            <Carousel.Caption>
               <h5><strong>Vitamin C on your skin?</strong></h5>
               <a href="/">Yes! Learn how you can use it to fight early skin aging</a>
               <small>Image source: https://bit.ly/3zRWNYX</small>
            </Carousel.Caption>
         </Carousel.Item>
         <Carousel.Item>
            <img
               className="responsive"
               src="https://bit.ly/2WSlDKl"
               alt="Third slide"
               />
            <Carousel.Caption>
               <h5><strong>Roses are red, violets are blue...</strong></h5>
               <a href="/">Did you know that rose water can help your skin too?</a>
               <small>Image source: https://bit.ly/2WSlDKl</small>
            </Carousel.Caption>
         </Carousel.Item>
      </Carousel>
   </div>
   <div className="columns container col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <div className="first-column container col-md-12 col-lg-3 col-sm-12 col-xs-12">
         <div className="trending">
            <h3 className="trending-title">
               <StarFill className="starfill" />
               Trending now!
            </h3>
            <ul className="trending-posts">
               <li className="trend-one">
                  <a href="/">How does retinoids work?<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 3.6K clicks
                  </span>
               </li>
               <li className="trend-one">
                  <a href="/">How to protect your skin during wintertime<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 3.2K clicks
                  </span>
               </li>
               <li className="trend-one">
                  <a href="/">How to prevent early skin aging<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 3.1K clicks
                  </span>
               </li>
               <li className="trend-one">
                  <a href="/">How much SPF should you use everyday<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 2.8K clicks
                  </span>
               </li>
               <li className="trend-one">
                  <a href="/">Does natural skincare recipes really work?<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 2.6K clicks
                  </span>
               </li>
            </ul>
         </div>
         <div className="more">
            <a href="/">Read more</a>
         </div>
      </div>
      <div className="second-column container col-md-12 col-lg-5 col-sm-12 col-xs-12">
         <div className="latest">
            <h3 className="latest-title">
               <ClockHistory className="clockhistory" />
               Latest posts
            </h3>
            <ul className="latest-posts">
               <li className="trend-one">
                  <a href="/">What SPF is best suitable for your skin<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 600 clicks &nbsp;
                  </span>
                  <a className="hashtag" href="/">#SPF </a>
               </li>
               <li className="trend-one">
                  <a href="/">What is psoriasis and what may cause it<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 310 clicks &nbsp;
                  </span>
                  <a className="hashtag" href="/">#psoriasis </a>
               </li>
               <li className="trend-one">
                  <a href="/">Why should you go cruelty-free when choosing your skincare products<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 920 clicks &nbsp;
                  </span>
                  <a className="hashtag" href="/">#cruelty-free </a>
               </li>
               <li className="trend-one">
                  <a href="/">We talked to a dermatologist about rosacea and how to treat it<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 1.1K clicks &nbsp;
                  </span>
                  <a className="hashtag" href="/">#rosacea </a>
               </li>
               <li className="trend-one">
                  <a href="/">How does your lifestyle impact your skin<br></br></a>
                  <span>
                     <EyeFill className="eye" />
                     &nbsp; 750 clicks &nbsp;
                  </span>
                  <a className="hashtag" href="/">#lifestyle </a>
               </li>
            </ul>
         </div>
         <div className="more">
            <a href="/">Read more</a>
         </div>
      </div>
      <div className="third-column container col-md-12 col-lg-3 col-sm-12 col-xs-12">
         <div className="trending">
            <h3 className="trending-title">
               <HeartFill className="heartfill" />
               Special content
            </h3>
            <ul className="trending-posts">
               <li className="trend-one"><a href="/">We launched a YouTube channel!<br></br></a><span> <a className="hashtag" href="/">#youtube </a></span></li>
               <li className="trend-one"><a href="/">Favourite products of the month<br></br></a><span><a className="hashtag" href="/">#favs</a> <a className="hashtag" href="/">#august</a></span></li>
               <li className="trend-one"><a href="/">We are launching our own skincare line!<br></br></a><span><a className="hashtag" href="/">#our-store </a></span></li>
               <li className="trend-one"><a href="/">Meet our sponsors!<br></br></a><span><a className="hashtag" href="/">#sponsored </a></span></li>
               <li className="trend-one"><a href="/">Products giveaway<br></br></a><span><a className="hashtag" href="/">#giveaway </a></span></li>
            </ul>
         </div>
         <div className="more">
            <a href="/">Read more</a>
         </div>
      </div>
   </div>
   <div className="footer col-md-12 col-lg-12">
      <div className="container">
         <h4 className="footer-title">Skincare Tricks and Tips</h4>
         <div className="footer-content">
            <div className="footer-column-one">
               <ul className="list-one">
                  <li className="list-one-title"><span>Institutional</span></li>
                  <li className="list-one-one">
                     <a href="/">
                        <Info className="footer-icon" />
                        &nbsp; About us
                     </a>
                  </li>
                  <li className="list-one-two">
                     <a href="/">
                        <Phone className="footer-icon" />
                        &nbsp; Contact
                     </a>
                  </li>
                  <li className="list-one-three">
                     <a href="/">
                        <ViewList className="footer-icon" />
                        &nbsp; Therms and conditions
                     </a>
                  </li>
               </ul>
            </div>
            <div className="footer-column-two">
               <ul className="list-two">
                  <li className="list-two-title"><span>Business</span></li>
                  <li className="list-two-one">
                     <a href="/">
                        <PersonPlusFill className="footer-icon" />
                        &nbsp; Be our partner
                     </a>
                  </li>
                  <li className="list-two-two">
                     <a href="/">
                        <BriefcaseFill className="footer-icon" />
                        &nbsp; Sponsor us
                     </a>
                  </li>
                  <li className="list-two-three">
                     <a href="/">
                        <Bag className="footer-icon" />
                        &nbsp; Store
                     </a>
                  </li>
               </ul>
            </div>
            <div className="footer-column-three">
               <ul className="list-three">
                  <li className="list-three-title"><span>&nbsp; Support</span></li>
                  <li className="list-three-one">
                     <a href="/">
                        <Question className="footer-icon" />
                        &nbsp; FAQ
                     </a>
                  </li>
                  <li className="list-three-two">
                     <a href="/">
                        <Exclamation className="footer-icon" />
                        &nbsp; Report a bug
                     </a>
                  </li>
                  <li className="list-three-three">
                     <a href="/">
                        <Tools className="footer-icon" />
                        &nbsp; Need help?
                     </a>
                  </li>
               </ul>
            </div>
            <div className="footer-column-four">
               <ul className="list-four">
                  <li className="list-four-title"><span>&nbsp; Social Media</span></li>
                  <li className="list-four-one">
                     <a href="/">
                        <FaInstagram className="footer-icon" />
                        &nbsp; Instagram
                     </a>
                  </li>
                  <li className="list-four-two">
                     <a href="/">
                        <FaYoutube className="footer-icon" />
                        &nbsp; YouTube
                     </a>
                  </li>
                  <li className="list-four-three">
                     <a href="/">
                        <FaFacebook />
                        &nbsp; Facebook
                     </a>
                  </li>
               </ul>
            </div>
         </div>
         <h5 className="footer-rights">STT - All rights reserved, 2021 - Developed by Bianca Leal</h5>
      </div>
   </div>
</div>
)
}