import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import Container from 'react-bootstrap/Container'
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'
import NavDropdown from 'react-bootstrap/NavDropdown'
import Form from 'react-bootstrap/Form'
import FormControl from 'react-bootstrap/FormControl'
import Button from 'react-bootstrap/Button'
import './cart.css'
import Table from 'react-bootstrap/Table';

function ButtonIncrement(props) {
  
    return (
      <button style={{ marginLeft: '.5rem'}} onClick={props.onClickFunc}>
      +
      </button>
    )
 }
 function ButtonDecrement(props) {
   
   return (
     <button style={{ marginLeft: '.5rem'}} onClick={props.onClickFunc}>
     -
     </button>
   )
 }
 function Display(props) {
   return (
     <label style={{ marginLeft: '.5rem'}} >{props.message}</label>
   )
 }

export default function HomePage() {

    const [counter, setCounter] = useState(1);
    const incrementCounter = () => setCounter(counter + 1);
    let decrementCounter = () => setCounter(counter - 1);

    if(counter<=1) {
        decrementCounter = () => setCounter(1);
      }

    return (
    <>
    <link href='https://fonts.googleapis.com/css?family=Cormorant Upright' rel='stylesheet'></link>
    <link href='https://fonts.googleapis.com/css?family=Cormorant Infant' rel='stylesheet'></link>
    <header>
    <div className="header">
    <Container>
    <div className="upper-row">
     <div>   
    <a href="/">Art Supply Store</a>
    </div>
    <div className="login">
    <span>Hello, Sarah!</span>
    <a href="#action2">Your profile</a>
    <a href="#action2">Sign out</a>
    </div>

    </div>
    
    <div className="lower-row row">
    <Navbar expand="lg">
  <Navbar.Toggle aria-controls="navbarScroll" />
  <Navbar.Collapse id="navbarScroll">
    <Nav
      className="mr-auto my-2 my-lg-0"
      style={{ maxHeight: '100px' }}
      navbarScroll
    >
    
      <Nav.Link href="#action1">Canvas</Nav.Link>
      <Nav.Link href="#action2">Brushes</Nav.Link>
      <Nav.Link href="#action1">Paints</Nav.Link>
      <Nav.Link href="#action2">Sprays</Nav.Link>
      <Nav.Link href="#action2">Easels</Nav.Link>
      <NavDropdown title="Outlet" id="navbarScrollingDropdown">
        <NavDropdown.Item href="#action3">Accessories</NavDropdown.Item>
        <NavDropdown.Item href="#action4">Art Desks</NavDropdown.Item>
        <NavDropdown.Item href="#action5">Office material</NavDropdown.Item>
      </NavDropdown>
    </Nav>
    <Form className="d-flex">
      <FormControl
        type="search"
        placeholder="Look for a product"
        className="mr-2"
        aria-label="Search"
      />
      <Button variant="outline-success">Search</Button>
    </Form>
    
  </Navbar.Collapse>
</Navbar>
    </div>
    
    </Container>
    </div>
    </header>
    <Container>

    <div className="cart-details">
  <Table responsive="sm">
    <thead>
      <tr>
        <th>#</th>
        <th>Product</th>
        <th>Value</th>
        <th>Amount</th>
        <th>Shipping</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>
        <a href="/">
        <img src="https://cf.shopee.com.br/file/a9d64d023bd57f35349b6be07f55834f" alt="wooden-easel" width="60" height="70"></img>
        <span>Wooden easel</span>
        </a>
        </td>
        <td>US$ 22.00</td>
        <td>    
        <div className="qty-button"> 
        <ButtonDecrement onClickFunc={decrementCounter}/>
        <Display message={counter}/> 
        <ButtonIncrement onClickFunc={incrementCounter}/>   
        </div>
        </td>
        <td>US$ 6.99</td>
      </tr>
      <tr>
        <td>2</td>
        <td>
        <a href="/">
        <img src="https://cdn.shopify.com/s/files/1/0064/3412/7939/products/4_3c9a1a67-c781-486e-8e73-f97e75e1f720_2048x.jpg?v=1608878213" alt="wooden-easel" width="60" height="70"></img>
        <span>Brush set</span>
        </a>
        </td>
        <td>US$ 8.99</td>
        <td><div className="qty-button"> 
        <ButtonDecrement onClickFunc={decrementCounter}/>
        <Display message={counter}/> 
        <ButtonIncrement onClickFunc={incrementCounter}/>   
        </div></td>
        <td>US$ 2.50</td>
      </tr>
      <tr>
        <td>3</td>
        <td>
        <a href="/">
        <img src="https://m.media-amazon.com/images/I/819l62REOaL._AC_SL1500_.jpg" alt="wooden-easel" width="60" height="70"></img>
        <span>Paint set</span>    
        </a>
        </td>
        <td>US$ 15.99</td>
        <td><div className="qty-button"> 
        <ButtonDecrement onClickFunc={decrementCounter}/>
        <Display message={counter}/> 
        <ButtonIncrement onClickFunc={incrementCounter}/>   
        </div></td>
        <td>US$ 3.99</td>
      </tr>
    </tbody>
  </Table>

</div> 

<div className="cart-subtotal">
    <h2 className="subtt">Subtotal</h2>
  <Table responsive="sm">
    <thead>
      <tr>
        <th>Items</th>
        <th>Products</th>
        <th>Shipping</th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <td>
        3
        </td>
        <td>
        US$46.98
        </td>
        <td>
        US$13.48
        </td>
      </tr>
    </tbody>
  </Table>

</div>

<div className="total">
<h3>Total</h3>
<div>
<span>US$60.46</span>
</div>
</div>
    </Container>   
<footer>
<div className="footer">
<Container>
<div className="footer-title">
<h4>Art</h4>
<h4>Supply</h4>
<h5>Store</h5>
</div>
<div className="footer-row">
<ul className="footer-list">
<li><a href="/">About us</a></li>    
<li><a href="/">Terms</a></li>   
<li><a href="/">Privacy</a></li>   
</ul>
<ul className="footer-list">
<li><a href="/">App</a></li>    
<li><a href="/">Collections</a></li>   
<li><a href="/">Coupons</a></li>   
</ul>
<ul className="footer-list">
<li><a href="/">Instagram</a></li>    
<li><a href="/">Facebook</a></li>   
<li><a href="/">YouTube</a></li>   
</ul>
</div>
</Container>
<div>
<p>Art Supply Store, 2021. Developed by Bianca Leal</p>    
</div>
</div> 
</footer>
    </>
    );
    }